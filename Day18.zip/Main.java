package day18;

public class Main {
	public static void main(String[] args) {
		dog d = new dog();
		bird b = new bird();
		d.move();
		d.speak();
		b.move();
		b.speak();
		System.out.println("is dog a mammal? "+Animal.isMammal("dog"));
		System.out.println("is bird a mammal? "+Animal.isMammal("bird"));
		System.out.println("dog category:"+Animal.CATEGORY);
		System.out.println("bird category:"+Animal.CATEGORY);
		
	}

}
