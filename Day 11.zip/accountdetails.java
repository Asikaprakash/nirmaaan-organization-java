package day14;


public class accountdetails {
  private int id;
  private String name;
  private double balance = 100000;
  private int Accountno;
  private int pin = 1234;
  
  public void setid(int id) {
		this.id = id;
	}
	public int getid(){
	return id;
		}
	public void setname(String name) {
		this.name = name;
	}
	public String getname() {
		return name;
	}
	public void setAccountno(int Accountno) {
		this.Accountno = Accountno;
	}
	public int getAccountno() {
		return Accountno;
	}
	public void setbalance(double balance,int pin) {
		if(this.pin == pin) {
		this.balance = balance;
	}else {
		System.out.println("invalidPin");
	}
	
	}
	public accountdetails(int id,String name,int Accountno,double balance,int pin) {

		this.id = id;
		this.name = name;
		this.Accountno = Accountno;
		if(this.pin == pin) {
		}else {
			System.out.println("invalidpin");
	}
	}
	public accountdetails() {
		
	}
	@Override
	public String toString() {
		return "accountdetails [id=" + id + ", name=" + name + ", balance=" + balance + ", accno=" + Accountno + "]";
	}
	public double getBalance() {
		// TODO Auto-generated method stub
		return 0;
	}
	
		
	}
  

