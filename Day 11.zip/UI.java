package day14;
import java.util.Scanner;

public class UI {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		accountdetails acc = new accountdetails();
		boolean isWork = true;

		while (isWork) {
			System.out.println("Enter 1 for Add Create Account");
			System.out.println("Enter 2 for Withdraw");
			System.out.println("Enter 3 for Show Account Details");
			System.out.println("Enter 4 for Deposit");
			System.out.println("Enter 5 for Exit");
			int key = sc.nextInt();

			if(key==1) {
				
					System.out.println("Enter the ID");
					int id = sc.nextInt();
					sc.nextLine();
					System.out.println("Enter the Name");
					String name = sc.nextLine();
					System.out.println("Enter the Balance");
					double balance = sc.nextDouble();
					System.out.println("Enter the Pin");
					int pin = sc.nextInt();
					acc = new accountdetails();
			}else if(key==2) {
				sc.nextLine();
					System.out.println("Enter the Pin:");
					int pin = sc.nextInt();
					System.out.println("Enter the Amount:");
					double amount = sc.nextInt();
					double existbalance = acc.getBalance();
					double total = existbalance-amount;
					System.out.println("Remaining amount:"+total);
					acc.setbalance(total, pin);
			}else if(key==3) {
					System.out.println(acc);
			
			}else if(key==4) {
					System.out.println("Enter the Pin:");
					int pin = sc.nextInt();
					System.out.println("Enter amount to amount:");
					double amount = sc.nextDouble();
					double existbalance = acc.getBalance();
					double total = existbalance+amount;
					System.out.println("Remaining amount:"+total);
					
			}else if(key==5){
				break;
			}
		}
		sc.close();
	}
}
		
	
	

